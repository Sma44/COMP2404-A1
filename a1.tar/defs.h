#ifndef DEFS_H
#define DEFS_H

#define MAX_ARR       64
#define MAX_PART      24

#define EVENTS_ID   3001

class Calendar;

void loadEvents(Calendar&);
void showMenu(int&);


#endif

