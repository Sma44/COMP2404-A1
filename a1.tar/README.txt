name: Samson Ma
Student number: 101264119
purpose: create a Calendar for Timmy Turtoise to store his events. stores 
         event category, time, date, and participants with a unique id for each event.

list of files: Date.cc, Date.h, Time.cc, Time.h, Event.cc, Event.h, 
Calendar.cc Calendar.h, defs.h, main.cc, Makefile, README.txt

compiling: navigate to working directory and run 'Make' in terminal.

launching: run './assignment01' to run the program.

run 'make clean' to remove files when done.